#!/bin/sh
source ./startup.sh restart