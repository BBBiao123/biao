#!/bin/sh

cd $(dirname $0)
source ./startup.sh stop
